# AvsarGo AI V2 — Standalone Render Beta

This is a **portable independent beta** for deployment outside Floot. It is NOT an official government portal and is **not a byte-for-byte export** of the existing Floot-built AvsarGo V2. It reproduces selected V2 functions in a standalone Node.js application with a Postgres database. User data in Floot is NOT migrated by this package.

## What works (once configured)

- Responsive AvsarGo-styled UI, Hindi / Hinglish / English guided chat.
- New registration/login (email/password), HttpOnly sessions and password hashing with scrypt.
- Encrypted, saved applicant profile (AES-256-GCM using a per-account derived key).
- Saved application drafts, preparation statuses and account data isolation.
- Export and delete saved workspace data (login account is NOT deleted).
- Document JPG/PNG picked locally, optional AI image-field extraction upon explicit consent (no permanent document uploads).
- Simulated browser autofill that never contacts government websites.
- Optional OpenAI Responses API for conversational AI (`OPENAI_API_KEY` required).

## Deliberately NOT implemented

Real government autofill, automated login, OTP handling, CAPTCHA bypass, actual form submission, payments, verified eligibility/deadline feed, email verification, password reset, encrypted permanent document vault, and production security/privacy audit. No claims of official affiliation. **Do not use real Aadhaar, PAN, biometrics, banking records or sensitive documents while this is a beta.**

## Deploy on Render (new project; do not reuse an old AvsarGo service)

1. Create a **new private GitHub repo** `avsargo-ai-v2-render` and upload **the contents of this folder** to the root of that repo. The old `VoidmeshAI/voidmesh-ai` repo and old Render services are not part of this migration.
2. In Render, create a **separate Postgres database** named `avsargo-ai-v2-db`, preferably in Singapore near the service. For serious production use, choose an appropriate paid/persistent plan and backup policy; any free database plan may expire and should be used for throwaway testing only.
3. Render → **New Web Service** → connect the new repository, branch `main`, runtime **Node**, region **Singapore**, start command `npm start`, build command `npm install` (or `npm ci` if you committed a lockfile). For low-cost testing choose Free plan if available.
4. Add environment variables in Render's Environment page (not inside Git):
   - `NODE_ENV=production`
   - `DATABASE_URL` = new database internal connection string.
   - `PROFILE_ENCRYPTION_KEY` = securely generated random key (`openssl rand -hex 32`). Losing/rotating it without a migration makes saved profiles unreadable. NEVER add this to the repository.
   - Optional: `OPENAI_API_KEY` = your own OpenAI API key, `OPENAI_MODEL=gpt-4.1-mini`. Without key, guided responses work but **real AI is disabled**.
5. Deploy. The app creates isolated `av2_*` tables when it boots. Test `https://<new-service>.onrender.com/api/health` (expected `{"ok":true,...}`).
6. Register a **dummy** test account. Verify login, save/reload profile, add draft, cross-account isolation, delete/export, and mobile layout. Keep beta test-only; do a security and compliance audit before inviting real customers.

> Important: This beta does not have email verification or a comprehensive incident-response, account recovery or retention plan. Do not market it as production-ready merely because `/api/health` returns 200.

## Development

`npm install`

Set a local Postgres `DATABASE_URL`, a random `PROFILE_ENCRYPTION_KEY`, then run `npm start`. Check syntax with `npm run check`.

## Data and security overview

The server uses per-user queries, origin-checks on API requests, HTTP-only SameSite session cookies, scrypt password hashing, AES-256-GCM profiles, no stored government credentials, request/AI quotas and data export/erase. The AI provider receives only the text users send or the specific image they consent to analyze. Prior AI-provider retention is governed by its policies. Use SSL on production endpoints; perform security review and add proper email verification, rate limiting at edge, audit logs, and lawful privacy notices before launch.
